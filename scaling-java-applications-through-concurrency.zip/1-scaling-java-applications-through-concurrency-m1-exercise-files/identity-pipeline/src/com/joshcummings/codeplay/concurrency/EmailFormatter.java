package com.joshcummings.codeplay.concurrency;

public interface EmailFormatter {
	void format(Identity identity);
}
