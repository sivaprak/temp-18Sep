package com.joshcummings.codeplay.concurrency;

public class NoValidAddressesException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
