package com.joshcummings.codeplay.concurrency;

public interface PhoneNumberFormatter {
	void format(Identity identity);
}
